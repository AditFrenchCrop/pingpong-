"use client"

import Pong from "../pong"

export default function SyntheticV0PageForDeployment() {
  return <Pong />
}